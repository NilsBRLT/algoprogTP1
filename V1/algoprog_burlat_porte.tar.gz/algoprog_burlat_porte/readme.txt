ALGORITHME & PROGRAMMATION - TP1
Par BURLAT Nils & PORTE Pierre-Antoine (1AA)

Dans le dossier où ce trouve ce readme, exécuter la commande « make » à partir d’une console. La compilation nécessite G++ avec C++11.
L’exécution du programme via la commmande « ./algoprog » présente les différentes utilisations possibles du programme et les paramètres à lui fournir.

Par exemple :
	./algoprog in.pbm out.ppm
	./algoprog in.pbm out.ppm BONUS
	./algoprog RANDOM 40 1000 1000 out.ppm
	./algoprog RANDOM 40 1000 1000 out.ppm BONUS
Le paramètre « BONUS » permet d’utiliser la fonction d’union de la question bonus.

L’exécution avec comme premier paramètre « test » permet de lancer les tests du programme : ./algoprog test